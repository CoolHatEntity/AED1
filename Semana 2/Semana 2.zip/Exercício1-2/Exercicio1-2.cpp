#include <stdio.h>

int main() {
    char nome[32] = {"Matheus S. Menezes"};
    printf("|========================================|\n");
    printf("|====| Aluno ==> %s |====|\n", nome);
    printf("|========================================|\n");
    return 0;
}
